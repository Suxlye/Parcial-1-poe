﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parcial1_u20231204_
{
    public partial class frmReservas : Form
    {
        public frmReservas()
        {
            InitializeComponent();
        }

        private void frmReservas_Load(object sender, EventArgs e)
        {
            cmbCategoria.Items.Clear();
            cmbCategoria.Items.Add("Acción");
            cmbCategoria.Items.Add("Comedia");
            cmbCategoria.Items.Add("Romance");
            cmbCategoria.SelectedIndex = -1;
            cmbPelicula.Items.Clear();
            txtNombre.Clear();
            txtDUI.Clear();
            btnAgregar.Enabled = false;
        }



        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                !txtDUI.MaskCompleted ||
                cmbCategoria.SelectedIndex == -1 ||
                cmbPelicula.SelectedIndex == -1)
            {
                MessageBox.Show("Todos los campos son obligatorios.");
                return;
            }

            dgvReservas.Rows.Add(txtNombre.Text, txtDUI.Text, cmbCategoria.SelectedItem, cmbPelicula.SelectedItem);

            txtNombre.Clear();
            txtDUI.Clear();
            cmbCategoria.SelectedIndex = -1;
            cmbPelicula.Items.Clear();
            btnAgregar.Enabled = false;
            txtNombre.Focus();
        }


        private void cmbCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cmbCategoria.SelectedItem == null) return;

            if (cmbCategoria.SelectedItem.ToString() == "Acción")
            {
                cmbPelicula.Items.Add("Avengers");
                cmbPelicula.Items.Add("Avengers2");
                cmbPelicula.Items.Add("Avengers 3");
            }
            else if (cmbCategoria.SelectedItem.ToString() == "Comedia")
            {
                cmbPelicula.Items.Add("Son como niños");
                cmbPelicula.Items.Add("Son como niños 2");
                cmbPelicula.Items.Add("Una esposa de mentiraas");
            }
            else if (cmbCategoria.SelectedItem.ToString() == "Romance")
            {
                cmbPelicula.Items.Add("Titanic");
                cmbPelicula.Items.Add("The noah Book");
                cmbPelicula.Items.Add("Yo antes de ti");
            }

            ValidarCampos();

        }


        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }

        private void ValidarCampos()
        {
            btnAgregar.Enabled =
                !string.IsNullOrWhiteSpace(txtNombre.Text) &&
                txtDUI.MaskCompleted &&
                cmbCategoria.SelectedIndex != -1 &&
                cmbPelicula.SelectedIndex != -1;
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {
            ValidarCampos();
        }

        private void txtDUI_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            ValidarCampos();
        }

        private void cmbPelicula_SelectedIndexChanged(object sender, EventArgs e)
        {
            ValidarCampos();
        }

        private void txtDUI_TextChanged(object sender, EventArgs e)
        {
            ValidarCampos();
        }
    }
}
